Link definition interfaces
==============

This repository holds all interfaces related to [PSR-13 (Link definition interfaces)][psr-url].

Note that this is not a Link implementation of its own. It is merely interfaces that describe the components of a Link.

The installable [package][package-url] and [implementations][implementation-url] are listed on Packagist.

[psr-url]: https://www.php-fig.org/psr/psr-13/
[package-url]: https://packagist.org/packages/psr/link
[implementation-url]: https://packagist.org/providers/psr/link-implementation
